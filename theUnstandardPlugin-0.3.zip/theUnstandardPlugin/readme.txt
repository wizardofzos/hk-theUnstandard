theUnstandard - plugin.

If you are using the Unstandard theme (like me) you might think
the manual 'lead_image' and 'secondary_image' custom field editting
is a bit cumbersome (I know I did).

That's why I wrote the little hk theUnstandard plugin.

This plugin (once activated) will set the two custom fields
to a random image from your post.

(this uses get_children, so it will *not* work on linked images)


Enjoy!


hk 2010
